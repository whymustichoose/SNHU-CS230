package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

public class GameService {

	// List to store active games
	private static List<Game> games = new ArrayList<>();

	// Identifier for the next game
	private static long nextGameId = 1;
	private static long nextPlayerId = 1;
	private static long nextTeamId = 1;

	// Single instance of GameService (singleton pattern)
	private static GameService service = null;

	// Private constructor to prevent direct instantiation
	private GameService() {}

	// Method to get the single GameService instance
	public static GameService getInstance() {
		if (service == null) {
			service = new GameService();
		}
		return service;
	}

	// Method to add a new game or retrieve an existing one by name
	public Game addGame(String name) {
		Game game = null;
		if (getGame(name) != null) {
			game = getGame(name);
		} else {
			game = new Game(nextGameId++, name);
			games.add(game);
		}
		return game;
	}

	// Method to get a game by its index in the list
	Game getGame(int index) {
		return games.get(index);
	}

	// Method to get a game by its unique ID
	public Game getGame(long id) {
		Game game = null;
		for (Game currGame : games) {
			if (currGame.getId() == id) {
				game = currGame;
				break;
			}
		}
		return game;
	}

	// Method to get a game by its unique name (case-insensitive)
	public Game getGame(String name) {
		Game game = null;
		for (Game currGame : games) {
			if (currGame.getName().equalsIgnoreCase(name)) {
				game = currGame;
				break;
			}
		}
		return game;
	}

	// Method to get the number of active games
	public int getGameCount() {
		return games.size();
	}

	// Method to get the next available player identifier
	public long getNextPlayerId() {
		return nextPlayerId++;
	}

	// Method to get the next available team identifier
	public long getNextTeamId() {
		return nextTeamId++;
	}
}
