package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a game
 *
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 *
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity {
	private static List<Team> teams = new ArrayList<>();

	/**
	 * Hide the default constructor to prevent creating empty instances.
	 */
	private Game() {
	}
	public Game(long id, String name) {
		this.id = id;
		this.name = name;
	}
	public Team addTeam(String name) {
	//String teams;
		Team tempTeam = null;
		for (Team thisTeam : teams) {
			if (thisTeam.name.equals(name)) {
				return thisTeam;
			}
		}
		GameService tempService = GameService.getInstance();

		tempTeam = new Team(tempService.getNextTeamId(), name);

		teams.add(tempTeam);
		return tempTeam;

	}

	/**
	 * Constructor with an identifier and name
	 */


	/**
	 * @return the id
	 */


	@Override
	public String toString() {

		return "Game [id=" + id + ", name=" + name + "]";
	}

}
